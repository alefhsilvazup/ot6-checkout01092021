package br.com.zupedu.orangetalents.casadocodigo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CasaDoCodigoApplicationTests {

	@Test
	void contextLoads() {
	}

}
